package fr.spawnplugin.plugin;

import net.md_5.bungee.api.ChatMessageType;
import net.md_5.bungee.api.chat.TextComponent;
import org.bukkit.*;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.util.Vector;

import java.util.*;

public class LobbyManager {

    private final SpawnPlugin plugin;

    // Joueurs actuellement dans le lobby
    private final Set<UUID> inLobby = new HashSet<>();

    // Tâches de freeze (pour bloquer tête + mouvement)
    private final Map<UUID, BukkitTask> freezeTasks = new HashMap<>();

    // Position du lobby (très haut dans le monde principal)
    private static final double LOBBY_X = 0.5;
    private static final double LOBBY_Y = 500;
    private static final double LOBBY_Z = 0.5;

    // Slots de l'inventaire forcé
    public static final int SLOT_START = 11; // ligne du milieu, position 2
    public static final int SLOT_GO = 14;    // ligne du milieu, position 5
    public static final int SLOT_CLOSE = 35; // dernière ligne, coin droit

    public LobbyManager(SpawnPlugin plugin) {
        this.plugin = plugin;
    }

    // Envoie un joueur au lobby et l'immobilise
    public void sendToLobby(Player player) {
        UUID uuid = player.getUniqueId();
        inLobby.add(uuid);

        // Téléporter au lobby
        World world = Bukkit.getWorlds().get(0);
        Location lobbyLoc = new Location(world, LOBBY_X, LOBBY_Y, LOBBY_Z, 0f, 0f);
        player.teleport(lobbyLoc);

        // Vider l'inventaire et forcer le lobby inventory
        player.getInventory().clear();
        openLobbyInventory(player);

        // Immobiliser après 1 tick (laisser le temps à la téléportation)
        Bukkit.getScheduler().runTaskLater(plugin, () -> freezePlayer(player), 2L);
    }

    // Ouvre l'inventaire forcé du lobby
    public void openLobbyInventory(Player player) {
        Inventory inv = Bukkit.createInventory(null, 54, ChatColor.DARK_GRAY + "Lobby");

        boolean firstJoin = plugin.getPlayerDataManager().isFirstJoin(player.getUniqueId());

        // Slot 11 : CLOCK nommée "Start"
        ItemStack startItem = new ItemStack(Material.CLOCK);
        ItemMeta startMeta = startItem.getItemMeta();
        if (firstJoin) {
            startMeta.setDisplayName(ChatColor.GREEN + "" + ChatColor.BOLD + "Start");
        } else {
            startMeta.setDisplayName(ChatColor.GRAY + "Start");
        }
        startItem.setItemMeta(startMeta);
        inv.setItem(SLOT_START, startItem);

        // Slot 14 : CLOCK nommée "Go"
        ItemStack goItem = new ItemStack(Material.CLOCK);
        ItemMeta goMeta = goItem.getItemMeta();
        if (!firstJoin) {
            goMeta.setDisplayName(ChatColor.GREEN + "" + ChatColor.BOLD + "Go");
        } else {
            goMeta.setDisplayName(ChatColor.GRAY + "Go");
        }
        goItem.setItemMeta(goMeta);
        inv.setItem(SLOT_GO, goItem);

        // Slot 35 : bloc rouge nommé "Fermer"
        ItemStack closeItem = new ItemStack(Material.RED_STAINED_GLASS_PANE);
        ItemMeta closeMeta = closeItem.getItemMeta();
        closeMeta.setDisplayName(ChatColor.RED + "" + ChatColor.BOLD + "Fermer");
        closeItem.setItemMeta(closeMeta);
        inv.setItem(SLOT_CLOSE, closeItem);

        player.openInventory(inv);
    }

    // Gèle le joueur (bloque mouvement + rotation tête)
    public void freezePlayer(Player player) {
        UUID uuid = player.getUniqueId();
        Location frozen = player.getLocation();

        // Stopper la vélocité
        player.setVelocity(new Vector(0, 0, 0));

        BukkitTask task = Bukkit.getScheduler().runTaskTimer(plugin, () -> {
            if (!player.isOnline()) {
                unfreeze(uuid);
                return;
            }
            // Forcer la position et la rotation à rester fixes
            Location current = player.getLocation();
            frozen.setYaw(0f);
            frozen.setPitch(0f);
            current.setX(frozen.getX());
            current.setY(frozen.getY());
            current.setZ(frozen.getZ());
            current.setYaw(0f);
            current.setPitch(0f);
            player.teleport(current);
            player.setVelocity(new Vector(0, 0, 0));

            // Garder l'inventaire ouvert si fermé
            if (inLobby.contains(uuid) && player.getOpenInventory().getTopInventory().getSize() < 54) {
                openLobbyInventory(player);
            }
        }, 0L, 1L);

        // Annuler ancienne tâche si existante
        if (freezeTasks.containsKey(uuid)) {
            freezeTasks.get(uuid).cancel();
        }
        freezeTasks.put(uuid, task);
    }

    // Débloque le joueur
    public void unfreeze(UUID uuid) {
        inLobby.remove(uuid);
        if (freezeTasks.containsKey(uuid)) {
            freezeTasks.get(uuid).cancel();
            freezeTasks.remove(uuid);
        }
    }

    // Vérifie si le joueur est dans le lobby
    public boolean isInLobby(UUID uuid) {
        return inLobby.contains(uuid);
    }

    // Donne les items de départ (1ère connexion uniquement)
    public void giveStarterItems(Player player) {
        player.getInventory().addItem(new ItemStack(Material.IRON_SWORD));
        player.getInventory().addItem(new ItemStack(Material.IRON_PICKAXE));
        player.getInventory().addItem(new ItemStack(Material.IRON_AXE));
    }

    // Téléporte au spawn principal du monde
    public void teleportToWorldSpawn(Player player) {
        World world = Bukkit.getWorlds().get(0);
        player.teleport(world.getSpawnLocation());
    }

    // Téléporte au point de spawn du joueur (lit ou spawn principal)
    public void teleportToPlayerSpawn(Player player) {
        Location bed = player.getBedSpawnLocation();
        if (bed != null) {
            player.teleport(bed);
        } else {
            teleportToWorldSpawn(player);
        }
    }
}
