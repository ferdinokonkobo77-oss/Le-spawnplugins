package fr.spawnplugin.plugin;

import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.util.UUID;

public class StartGoCommand implements CommandExecutor {

    private final SpawnPlugin plugin;
    private final boolean isStart; // true = /start, false = /go

    public StartGoCommand(SpawnPlugin plugin, boolean isStart) {
        this.plugin = plugin;
        this.isStart = isStart;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage(ChatColor.RED + "Cette commande ne peut etre utilisee que par un joueur.");
            return true;
        }

        UUID uuid = player.getUniqueId();

        // Doit être dans le lobby
        if (!plugin.getLobbyManager().isInLobby(uuid)) {
            player.sendMessage(ChatColor.RED + "Vous n'etes pas dans le lobby.");
            return true;
        }

        boolean firstJoin = plugin.getPlayerDataManager().isFirstJoin(uuid);

        if (isStart) {
            // /start
            if (firstJoin) {
                plugin.getLobbyManager().unfreeze(uuid);
                plugin.getPlayerDataManager().setHasStarted(uuid);
                plugin.getLobbyManager().giveStarterItems(player);
                plugin.getLobbyManager().teleportToWorldSpawn(player);
                player.sendMessage(ChatColor.GREEN + "Bienvenue ! Bonne survie !");
            } else {
                player.sendMessage(ChatColor.RED + "Cette commande n'est pas valide ! Tapez " +
                        ChatColor.BOLD + "/go" + ChatColor.RED + " pour continuer.");
            }
        } else {
            // /go
            if (!firstJoin) {
                plugin.getLobbyManager().unfreeze(uuid);
                plugin.getLobbyManager().teleportToPlayerSpawn(player);
                player.sendMessage(ChatColor.GREEN + "Bon retour !");
            } else {
                player.sendMessage(ChatColor.RED + "Cette commande n'est pas valide ! Tapez " +
                        ChatColor.BOLD + "/start" + ChatColor.RED + " pour commencer.");
            }
        }

        return true;
    }
}
