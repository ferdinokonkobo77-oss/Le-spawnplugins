package fr.spawnplugin.plugin;

import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryDragEvent;

import java.util.UUID;

public class InventoryListener implements Listener {

    private final SpawnPlugin plugin;

    public InventoryListener(SpawnPlugin plugin) {
        this.plugin = plugin;
    }

    // ===================== CLIC DANS L'INVENTAIRE =====================

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onInventoryClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player player)) return;

        UUID uuid = player.getUniqueId();

        // Annuler tout clic dans le lobby pour éviter de voler les items
        if (plugin.getLobbyManager().isInLobby(uuid)) {
            event.setCancelled(true);

            int slot = event.getRawSlot();
            boolean firstJoin = plugin.getPlayerDataManager().isFirstJoin(uuid);

            // Clic sur START (slot 11)
            if (slot == LobbyManager.SLOT_START) {
                handleStartClick(player, firstJoin);
            }
            // Clic sur GO (slot 14)
            else if (slot == LobbyManager.SLOT_GO) {
                handleGoClick(player, firstJoin);
            }
            // Clic sur FERMER (slot 35)
            else if (slot == LobbyManager.SLOT_CLOSE) {
                // Poser la métadonnée AVANT de fermer
                player.setMetadata("closedByButton",
                        new org.bukkit.metadata.FixedMetadataValue(plugin, true));
                player.closeInventory();
                // Le joueur reste immobile, inventaire fermé
                // Il devra taper /start ou /go dans le chat
                String cmd = firstJoin ? "/start" : "/go";
                player.sendMessage(ChatColor.YELLOW + "Inventaire ferme. Tapez " +
                        ChatColor.GREEN + cmd + ChatColor.YELLOW + " dans le chat pour continuer.");
            }
        }
    }

    private void handleStartClick(Player player, boolean firstJoin) {
        if (firstJoin) {
            // Première connexion → donner items + téléporter au spawn
            plugin.getLobbyManager().unfreeze(player.getUniqueId());
            player.closeInventory();
            plugin.getPlayerDataManager().setHasStarted(player.getUniqueId());
            plugin.getLobbyManager().giveStarterItems(player);
            plugin.getLobbyManager().teleportToWorldSpawn(player);
            player.sendMessage(ChatColor.GREEN + "Bienvenue ! Bonne survie !");
        } else {
            // Pas la première connexion → Start invalide
            player.sendMessage(ChatColor.RED + "Cette commande n'est pas valide ! Appuyez sur " +
                    ChatColor.BOLD + "GO" + ChatColor.RED + " pour continuer.");
        }
    }

    private void handleGoClick(Player player, boolean firstJoin) {
        if (!firstJoin) {
            // Reconnexion → téléporter au point de spawn (sans donner d'items)
            plugin.getLobbyManager().unfreeze(player.getUniqueId());
            player.closeInventory();
            plugin.getLobbyManager().teleportToPlayerSpawn(player);
            player.sendMessage(ChatColor.GREEN + "Bon retour !");
        } else {
            // Première connexion → Go invalide
            player.sendMessage(ChatColor.RED + "Cette commande n'est pas valide ! Appuyez sur " +
                    ChatColor.BOLD + "START" + ChatColor.RED + " pour commencer.");
        }
    }

    // ===================== EMPÊCHER FERMETURE FORCÉE =====================

    @EventHandler
    public void onInventoryClose(InventoryCloseEvent event) {
        if (!(event.getPlayer() instanceof Player player)) return;
        UUID uuid = player.getUniqueId();

        if (!plugin.getLobbyManager().isInLobby(uuid)) return;

        // Vérifier si l'inventaire fermé est bien le lobby (titre)
        String title = event.getView().getTitle();
        if (!title.contains("Lobby")) return;

        // Rouvrir après 1 tick sauf si le joueur a cliqué "Fermer"
        // On détecte via une métadonnée posée par le clic sur Fermer
        if (!player.hasMetadata("closedByButton")) {
            plugin.getServer().getScheduler().runTaskLater(plugin, () -> {
                if (player.isOnline() && plugin.getLobbyManager().isInLobby(uuid)) {
                    plugin.getLobbyManager().openLobbyInventory(player);
                }
            }, 1L);
        } else {
            player.removeMetadata("closedByButton", plugin);
        }
    }

    // Empêcher le drag d'items dans l'inventaire lobby
    @EventHandler
    public void onDrag(InventoryDragEvent event) {
        if (!(event.getWhoClicked() instanceof Player player)) return;
        if (plugin.getLobbyManager().isInLobby(player.getUniqueId())) {
            event.setCancelled(true);
        }
    }
}
