package fr.spawnplugin.plugin;

import net.md_5.bungee.api.ChatMessageType;
import net.md_5.bungee.api.chat.TextComponent;
import org.bukkit.ChatColor;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class CooldownManager {

    private final SpawnPlugin plugin;

    // Temps restant du cooldown par joueur (en secondes)
    private final Map<UUID, Integer> cooldowns = new HashMap<>();

    // Tâches de décompte par joueur
    private final Map<UUID, BukkitTask> tasks = new HashMap<>();

    public CooldownManager(SpawnPlugin plugin) {
        this.plugin = plugin;
    }

    // Déclenche ou reset le cooldown à 10 secondes
    public void triggerCooldown(Player player) {
        UUID uuid = player.getUniqueId();

        // Reset à 10 (que ce soit un nouveau déclenchement ou un reset)
        cooldowns.put(uuid, 10);

        // Si une tâche existe déjà, on ne recrée pas (elle continue avec la valeur mise à jour)
        if (tasks.containsKey(uuid)) {
            return;
        }

        // Démarrer le décompte
        BukkitTask task = plugin.getServer().getScheduler().runTaskTimer(plugin, () -> {
            if (!player.isOnline()) {
                cancelCooldown(uuid);
                return;
            }

            int remaining = cooldowns.getOrDefault(uuid, 0);

            if (remaining <= 0) {
                // Cooldown terminé
                cancelCooldown(uuid);
                // Effacer l'action bar
                player.spigot().sendMessage(ChatMessageType.ACTION_BAR,
                        new TextComponent(""));
                return;
            }

            // Afficher dans l'action bar
            String bar = ChatColor.RED + "" + ChatColor.BOLD + "Cooldown : " +
                    ChatColor.YELLOW + remaining + ChatColor.RED + "s" +
                    ChatColor.GRAY + " - Deconnexion impossible !";
            player.spigot().sendMessage(ChatMessageType.ACTION_BAR, new TextComponent(bar));

            cooldowns.put(uuid, remaining - 1);

        }, 0L, 20L); // toutes les 20 ticks = 1 seconde

        tasks.put(uuid, task);
    }

    // Vérifie si le joueur a un cooldown actif
    public boolean hasCooldown(UUID uuid) {
        return cooldowns.containsKey(uuid) && cooldowns.get(uuid) > 0;
    }

    // Annule le cooldown d'un joueur
    public void cancelCooldown(UUID uuid) {
        cooldowns.remove(uuid);
        if (tasks.containsKey(uuid)) {
            tasks.get(uuid).cancel();
            tasks.remove(uuid);
        }
    }

    // Annule tous les cooldowns (lors du disable)
    public void cancelAll() {
        for (BukkitTask task : tasks.values()) {
            task.cancel();
        }
        tasks.clear();
        cooldowns.clear();
    }
}
