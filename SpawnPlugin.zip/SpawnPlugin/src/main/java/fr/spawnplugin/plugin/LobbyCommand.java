package fr.spawnplugin.plugin;

import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class LobbyCommand implements CommandExecutor {

    private final SpawnPlugin plugin;

    public LobbyCommand(SpawnPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage(ChatColor.RED + "Cette commande ne peut etre utilisee que par un joueur.");
            return true;
        }

        if (!player.isOp()) {
            player.sendMessage(ChatColor.RED + "Vous n'avez pas la permission d'utiliser cette commande.");
            return true;
        }

        // Envoyer l'opérateur au lobby
        plugin.getLobbyManager().sendToLobby(player);
        player.sendMessage(ChatColor.GREEN + "Vous avez ete teleporte au lobby.");
        return true;
    }
}
