package fr.spawnplugin.plugin;

import org.bukkit.plugin.java.JavaPlugin;

public class SpawnPlugin extends JavaPlugin {

    private PlayerDataManager playerDataManager;
    private LobbyManager lobbyManager;
    private CooldownManager cooldownManager;

    @Override
    public void onEnable() {
        playerDataManager = new PlayerDataManager(this);
        cooldownManager = new CooldownManager(this);
        lobbyManager = new LobbyManager(this);

        getServer().getPluginManager().registerEvents(new PlayerListener(this), this);
        getServer().getPluginManager().registerEvents(new InventoryListener(this), this);

        getCommand("lobby").setExecutor(new LobbyCommand(this));
        getCommand("start").setExecutor(new StartGoCommand(this, true));
        getCommand("go").setExecutor(new StartGoCommand(this, false));

        getLogger().info("SpawnPlugin active !");
    }

    @Override
    public void onDisable() {
        cooldownManager.cancelAll();
        getLogger().info("SpawnPlugin desactive !");
    }

    public PlayerDataManager getPlayerDataManager() { return playerDataManager; }
    public LobbyManager getLobbyManager() { return lobbyManager; }
    public CooldownManager getCooldownManager() { return cooldownManager; }
}
