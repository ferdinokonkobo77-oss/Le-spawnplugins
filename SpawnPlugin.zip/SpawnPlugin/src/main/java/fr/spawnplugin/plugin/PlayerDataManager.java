package fr.spawnplugin.plugin;

import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.IOException;
import java.util.UUID;

public class PlayerDataManager {

    private final SpawnPlugin plugin;
    private File dataFile;
    private FileConfiguration dataConfig;

    public PlayerDataManager(SpawnPlugin plugin) {
        this.plugin = plugin;
        dataFile = new File(plugin.getDataFolder(), "playerdata.yml");
        if (!dataFile.exists()) {
            plugin.getDataFolder().mkdirs();
            try {
                dataFile.createNewFile();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        dataConfig = YamlConfiguration.loadConfiguration(dataFile);
    }

    // Vérifie si c'est la toute première connexion (jamais cliqué Start)
    public boolean isFirstJoin(UUID uuid) {
        return !dataConfig.contains(uuid.toString() + ".hasStarted");
    }

    // Marque que le joueur a validé son Start (première connexion terminée)
    public void setHasStarted(UUID uuid) {
        dataConfig.set(uuid.toString() + ".hasStarted", true);
        save();
    }

    // Vérifie si le joueur a déjà fait sa première connexion
    public boolean hasStarted(UUID uuid) {
        return dataConfig.getBoolean(uuid.toString() + ".hasStarted", false);
    }

    private void save() {
        try {
            dataConfig.save(dataFile);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
