package fr.spawnplugin.plugin;

import org.bukkit.*;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.*;

import java.util.UUID;

public class PlayerListener implements Listener {

    private final SpawnPlugin plugin;

    public PlayerListener(SpawnPlugin plugin) {
        this.plugin = plugin;
    }

    // ===================== CONNEXION =====================

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        Player player = event.getPlayer();
        UUID uuid = player.getUniqueId();

        // Envoyer au lobby dans tous les cas (première connexion ou reconnexion)
        plugin.getServer().getScheduler().runTaskLater(plugin, () -> {
            plugin.getLobbyManager().sendToLobby(player);
        }, 5L);
    }

    // ===================== DÉCONNEXION =====================

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onQuit(PlayerQuitEvent event) {
        Player player = event.getPlayer();
        UUID uuid = player.getUniqueId();

        // Nettoyer les données en mémoire
        plugin.getLobbyManager().unfreeze(uuid);
        plugin.getCooldownManager().cancelCooldown(uuid);
    }

    // ===================== BLOQUER LA DÉCO SI COOLDOWN =====================

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onKick(PlayerKickEvent event) {
        // Laisser passer les kicks serveur normaux
    }

    // Bloquer la déconnexion pendant le cooldown via PlayerQuitEvent n'est pas possible directement
    // On utilise le packet via PlayerConnection - géré via login event + custom quit handling
    // Note: En Spigot pur on ne peut pas bloquer le quit, mais on peut ignorer le point de spawn
    // La logique de cooldown empêche le changement de spawn sauvegardé

    // ===================== DÉGÂTS → RESET COOLDOWN =====================

    @EventHandler
    public void onDamage(EntityDamageEvent event) {
        if (!(event.getEntity() instanceof Player player)) return;
        if (plugin.getLobbyManager().isInLobby(player.getUniqueId())) return;

        EntityDamageEvent.DamageCause cause = event.getCause();

        // Causes qui déclenchent le cooldown
        boolean dangerous =
                cause == EntityDamageEvent.DamageCause.LAVA ||
                cause == EntityDamageEvent.DamageCause.FIRE ||
                cause == EntityDamageEvent.DamageCause.FIRE_TICK ||
                cause == EntityDamageEvent.DamageCause.ENTITY_ATTACK ||
                cause == EntityDamageEvent.DamageCause.ENTITY_SWEEP_ATTACK ||
                cause == EntityDamageEvent.DamageCause.PROJECTILE ||
                cause == EntityDamageEvent.DamageCause.MAGIC ||
                cause == EntityDamageEvent.DamageCause.POISON ||
                cause == EntityDamageEvent.DamageCause.WITHER;

        if (dangerous) {
            plugin.getCooldownManager().triggerCooldown(player);
        }
    }

    // Dégâts par entité (autre joueur) → reset cooldown
    @EventHandler
    public void onDamageByEntity(EntityDamageByEntityEvent event) {
        if (!(event.getEntity() instanceof Player player)) return;
        if (plugin.getLobbyManager().isInLobby(player.getUniqueId())) return;

        plugin.getCooldownManager().triggerCooldown(player);
    }

    // ===================== MORT → PAS DE LOBBY =====================

    @EventHandler
    public void onDeath(PlayerDeathEvent event) {
        Player player = event.getEntity();
        // Marquer que le joueur est mort (pas de lobby au respawn)
        // On utilise les métadonnées temporaires
        player.setMetadata("justDied",
                new org.bukkit.metadata.FixedMetadataValue(plugin, true));
    }

    @EventHandler
    public void onRespawn(PlayerRespawnEvent event) {
        Player player = event.getPlayer();
        // Après une mort : pas de lobby, spawn normal (géré par Bukkit)
        // Retirer le flag de mort
        if (player.hasMetadata("justDied")) {
            player.removeMetadata("justDied", plugin);
        }
        // Ne pas envoyer au lobby → laisser Bukkit gérer le respawn normal
    }

    // ===================== BLOQUER MOUVEMENTS DANS LOBBY =====================

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onMove(PlayerMoveEvent event) {
        Player player = event.getPlayer();
        if (!plugin.getLobbyManager().isInLobby(player.getUniqueId())) return;

        // Bloquer tout mouvement de position (autoriser rotation forcée à 0)
        Location from = event.getFrom();
        Location to = event.getTo();

        if (to == null) return;

        // Si la position XYZ change, annuler
        if (from.getX() != to.getX() || from.getY() != to.getY() || from.getZ() != to.getZ()) {
            event.setTo(from.clone().setDirection(new org.bukkit.util.Vector(0, 0, 1)));
            event.getTo().setYaw(0f);
            event.getTo().setPitch(0f);
        }
    }

    // Bloquer les commandes non autorisées dans le lobby
    @EventHandler
    public void onCommand(PlayerCommandPreprocessEvent event) {
        Player player = event.getPlayer();
        if (!plugin.getLobbyManager().isInLobby(player.getUniqueId())) return;

        String cmd = event.getMessage().toLowerCase().split(" ")[0];

        // Autoriser seulement /start et /go (et /lobby pour les ops)
        if (!cmd.equals("/start") && !cmd.equals("/go") &&
            !(cmd.equals("/lobby") && player.isOp())) {
            event.setCancelled(true);
            player.sendMessage(ChatColor.RED + "Vous ne pouvez pas utiliser de commandes dans le lobby.");
        }
    }

    // Bloquer le drop d'items dans le lobby
    @EventHandler
    public void onDrop(PlayerDropItemEvent event) {
        if (plugin.getLobbyManager().isInLobby(event.getPlayer().getUniqueId())) {
            event.setCancelled(true);
        }
    }
}
